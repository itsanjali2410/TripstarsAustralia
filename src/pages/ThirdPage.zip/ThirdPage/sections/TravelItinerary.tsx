import React from 'react'
import BaliItinerary from './BaliItinerary'

const TravelItinerary = () => {
  return (
    <div>
      <BaliItinerary/>
    </div>
  )
}

export default TravelItinerary