import AboutPage from './LandingPage/about/AboutPage'

function App() {
 
  return (
    <>
    <AboutPage />
    </>
  )
}

export default App
