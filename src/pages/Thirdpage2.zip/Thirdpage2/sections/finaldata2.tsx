import { Vietnam } from "../../../components/data";

interface PackageData {
  packageId: string;
  packageName: string;
  totalGuests: number;
  nights: number;
  days: number;
  startCity: string;
  destinationCovered: string;
  totalPackagePrice: string;
  packageImage: string;
  pricePerAdult?: string; // ✅ Make it optional
  itinerary: { [day: string]: string[] }[];
  hotelsPricing: {
    "4Star": { city: string; hotels: string[] }[];
    "5Star": { city: string; hotels: string[] }[];
  };
  optionalActivities: { name: string; costPerAdult: string }[];
  inclusions: string[];
  exclusions: string[];
  termsConditions: string[];
  cancellationPolicy: Record<string, string>;
}


// ✅ FinalData Type Definition
const Finaldata: Record<string, Record<string, PackageData>> = {
  bali: {
    bali1: {
      packageId: "S04390",
      packageName: "Ultimate Bali & Nusa Penida Adventure 6N7D",
      totalGuests: 2,
      nights: 6,
      days: 7,
      startCity: "Mumbai",
      destinationCovered: "Bali",
      totalPackagePrice: "INR 70,000",
 
      packageImage:
        "https://plus.unsplash.com/premium_photo-1661955632358-85564b2810b2?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8YmFsaSUyMGlzbGFuZHxlbnwwfHwwfHx8MA%3D%3D",
        itinerary: [
          { " Day 1: Arrival in Bali & Transfer to Hotel": ["Welcome to Bali! Today is the First day of your trip you will arrive at Denpasar Bali airport and will be transferred to your hotel in Bali. Your first day's schedule depends on the flight arrival time. Usually, this day will be free for you at leisure. Overnight stay at Hotel accommodation"] },
          { "Day 2: Benoa Water Sports": ["Experience a water-filled adventure at Benoa Bay with an exciting. An ideal Bali is incomplete without Bali Water Sport at famous Tanjung Benoa Beach. This beach based know for each aquatic adventure is located in the benoa peninsula far away from the Hustle and bustle. watersport with Banana Boat, Parasailing, Jet Ski."] },
          { " Day 3: Uluwatu Sunset Tour with Kecak Dance": ["Visit the beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. The beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. Post sunset witness the Kecak and Fire Dance - Completely dramatic. Originally from Ramayana this show depicts the famous ‘Lanka Dahan’ episode wherein Hanuman sets fire to the kingdom of Ravana. The enthralling ‘kecak, kecak’ chant is the USP."] },
          { " Day 4: Full-Day West Nusa Penida Tour": ["You will be taken to witness Tegalalang Rice Terraces - probably the busiest and most famous waterfall in Bali, and it’s super easy to reach from Ubud. It only takes about 15 minutes to hike down the steps to the waterfall, but the way back up is a good workout with a lot of humidity and uneven stone steps (the steps feel like they were made for giants!)."] },
          { "Day 5: Ubud Exploration & Scenic Attractions": ["The Ubud Art Market is a great place to find beautiful silk scarves, lightweight shirts, statues, kites, handmade woven bags, baskets or hats and many other hand-crafted goods. Locally known as Pasar Seni Ubud, the market is opposite the Puri Saren Royal Ubud Palace and opens daily. Most of the goods found at the Ubud Market are made in the neighbouring villages of Pengosekan, Tegallalang, Payangan and Peliatan. The location of the Ubud Art Market, which is centred among the art producing villages and at the centre of Ubud itself, makes it a strategic shopping place for Balinese handicrafts and souvenirs."] },
          { "Day 6: Relax & Explore Bali at Your Own Pace": ["Day at Leisure Day free at leisure, enjoy by your own."] },
          { "Day 7: Departure – Bali to Denpasar Airport": ["Take a bag full of memories to cherish | Check out from the hotel and meet the representative who will take you to the Denpasar airport to board board your return flight back home."] },
        ],
      hotelsPricing: {
        "4Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Swiss-Belhotel Rainforest Kuta", "The One Legion", "Golden Tulip Jineng Resort", "Kuta Central"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Alam Puisi Ubud", "Ashoka Tree Resort Ubud", "Bhumi Linggah", "Ubud Heaven Sayan"] },
        ],
        "5Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Bintang Bali Resort", "Royal Tulip Springhill Resort", "Pullman Bali Legian Beach"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Asvara Villa Ubud", "FuramaXclusive Resort & Villas", "Hideaway Village Bali"] },
        ],
      },
      optionalActivities: [
        { name: "ATV Quad Bike & White Water Rafting Adventure", costPerAdult: "₹ 5000 /-" },
        { name: "Bali Safari with Marine Park & Jungle Hopper Pass", costPerAdult: "₹ 6000 /-" },
        { name: "Candle Light Dinner", costPerAdult: "₹ 3000 /-" },
        { name: "Lempuyang Temple, Tirta Gangga & Waterfall Tour", costPerAdult: "₹ 2960 /-" },
        { name: "Floating Breakfast", costPerAdult: "₹ 2500 /- per couple" },
      ],
      inclusions: [
        "Arrival in Bali Denpasar and transfer to hotel by private car.",
        "Benoa Water Sports - By Private Car.",
        "Uluwatu Sunset Tour with Kecak Dance on Private car.",
        "Ulundanu Temple of Bedugul tour on Private car.",
        "Git Git Waterfall on Private car.",
        "Tanah Lot Temple on Private car.",
      ],
      exclusions: [
        "International Tourism Levy of IDR 150000 per person.",
        "Visa on Arrival: USD 35 per person.",
      ],
      termsConditions: ["All payment should be cleared at least 30 days before departure."],
      cancellationPolicy: {
        "30DaysOrMore": "25% of total cost",
        "29To20Days": "50% of total cost",
        "19DaysOrLess": "100% of total cost",
      },
    },
    bali2: {
      packageId: "S04390",
      packageName: "Bali with gilli",
      totalGuests: 2,
      nights: 6,
      days: 7,
      startCity: "Mumbai",
      destinationCovered: "Bali",
      totalPackagePrice: "INR 70,000",
 
      packageImage:
        "https://plus.unsplash.com/premium_photo-1661955632358-85564b2810b2?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8YmFsaSUyMGlzbGFuZHxlbnwwfHwwfHx8MA%3D%3D",
        itinerary: [
          { " Day 1: Arrival in Bali & Transfer to Hotel": ["Welcome to Bali! Today is the First day of your trip you will arrive at Denpasar Bali airport and will be transferred to your hotel in Bali. Your first day's schedule depends on the flight arrival time. Usually, this day will be free for you at leisure. Overnight stay at Hotel accommodation"] },
          { "Day 2: Benoa Water Sports": ["Experience a water-filled adventure at Benoa Bay with an exciting. An ideal Bali is incomplete without Bali Water Sport at famous Tanjung Benoa Beach. This beach based know for each aquatic adventure is located in the benoa peninsula far away from the Hustle and bustle. watersport with Banana Boat, Parasailing, Jet Ski."] },
          { " Day 3: Uluwatu Sunset Tour with Kecak Dance": ["Visit the beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. The beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. Post sunset witness the Kecak and Fire Dance - Completely dramatic. Originally from Ramayana this show depicts the famous ‘Lanka Dahan’ episode wherein Hanuman sets fire to the kingdom of Ravana. The enthralling ‘kecak, kecak’ chant is the USP."] },
          { " Day 4: Full-Day West Nusa Penida Tour": ["You will be taken to witness Tegalalang Rice Terraces - probably the busiest and most famous waterfall in Bali, and it’s super easy to reach from Ubud. It only takes about 15 minutes to hike down the steps to the waterfall, but the way back up is a good workout with a lot of humidity and uneven stone steps (the steps feel like they were made for giants!)."] },
          { "Day 5: Ubud Exploration & Scenic Attractions": ["The Ubud Art Market is a great place to find beautiful silk scarves, lightweight shirts, statues, kites, handmade woven bags, baskets or hats and many other hand-crafted goods. Locally known as Pasar Seni Ubud, the market is opposite the Puri Saren Royal Ubud Palace and opens daily. Most of the goods found at the Ubud Market are made in the neighbouring villages of Pengosekan, Tegallalang, Payangan and Peliatan. The location of the Ubud Art Market, which is centred among the art producing villages and at the centre of Ubud itself, makes it a strategic shopping place for Balinese handicrafts and souvenirs."] },
          { "Day 6: Relax & Explore Bali at Your Own Pace": ["Day at Leisure Day free at leisure, enjoy by your own."] },
          { "Day 7: Departure – Bali to Denpasar Airport": ["Take a bag full of memories to cherish | Check out from the hotel and meet the representative who will take you to the Denpasar airport to board board your return flight back home."] },
        ],
      hotelsPricing: {
        "4Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Swiss-Belhotel Rainforest Kuta", "The One Legion", "Golden Tulip Jineng Resort", "Kuta Central"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Alam Puisi Ubud", "Ashoka Tree Resort Ubud", "Bhumi Linggah", "Ubud Heaven Sayan"] },
        ],
        "5Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Bintang Bali Resort", "Royal Tulip Springhill Resort", "Pullman Bali Legian Beach"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Asvara Villa Ubud", "FuramaXclusive Resort & Villas", "Hideaway Village Bali"] },
        ],
      },
      optionalActivities: [
        { name: "ATV Quad Bike & White Water Rafting Adventure", costPerAdult: "₹ 5000 /-" },
        { name: "Bali Safari with Marine Park & Jungle Hopper Pass", costPerAdult: "₹ 6000 /-" },
        { name: "Candle Light Dinner", costPerAdult: "₹ 3000 /-" },
        { name: "Lempuyang Temple, Tirta Gangga & Waterfall Tour", costPerAdult: "₹ 2960 /-" },
        { name: "Floating Breakfast", costPerAdult: "₹ 2500 /- per couple" },
      ],
      inclusions: [
        "Arrival in Bali Denpasar and transfer to hotel by private car.",
        "Benoa Water Sports - By Private Car.",
        "Uluwatu Sunset Tour with Kecak Dance on Private car.",
        "Ulundanu Temple of Bedugul tour on Private car.",
        "Git Git Waterfall on Private car.",
        "Tanah Lot Temple on Private car.",
      ],
      exclusions: [
        "International Tourism Levy of IDR 150000 per person.",
        "Visa on Arrival: USD 35 per person.",
      ],
      termsConditions: ["All payment should be cleared at least 30 days before departure."],
      cancellationPolicy: {
        "30DaysOrMore": "25% of total cost",
        "29To20Days": "50% of total cost",
        "19DaysOrLess": "100% of total cost",
      },
    },
    bali3: {
      packageId: "S04390",
      packageName: "Bali essense",
      totalGuests: 2,
      nights: 6,
      days: 7,
      startCity: "Mumbai",
      destinationCovered: "Bali",
      totalPackagePrice: "INR 70,000",
 
      packageImage:
        "https://plus.unsplash.com/premium_photo-1661955632358-85564b2810b2?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8YmFsaSUyMGlzbGFuZHxlbnwwfHwwfHx8MA%3D%3D",
        itinerary: [
          { " Day 1: Arrival in Bali & Transfer to Hotel": ["Welcome to Bali! Today is the First day of your trip you will arrive at Denpasar Bali airport and will be transferred to your hotel in Bali. Your first day's schedule depends on the flight arrival time. Usually, this day will be free for you at leisure. Overnight stay at Hotel accommodation"] },
          { "Day 2: Benoa Water Sports": ["Experience a water-filled adventure at Benoa Bay with an exciting. An ideal Bali is incomplete without Bali Water Sport at famous Tanjung Benoa Beach. This beach based know for each aquatic adventure is located in the benoa peninsula far away from the Hustle and bustle. watersport with Banana Boat, Parasailing, Jet Ski."] },
          { " Day 3: Uluwatu Sunset Tour with Kecak Dance": ["Visit the beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. The beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. Post sunset witness the Kecak and Fire Dance - Completely dramatic. Originally from Ramayana this show depicts the famous ‘Lanka Dahan’ episode wherein Hanuman sets fire to the kingdom of Ravana. The enthralling ‘kecak, kecak’ chant is the USP."] },
          { " Day 4: Full-Day West Nusa Penida Tour": ["You will be taken to witness Tegalalang Rice Terraces - probably the busiest and most famous waterfall in Bali, and it’s super easy to reach from Ubud. It only takes about 15 minutes to hike down the steps to the waterfall, but the way back up is a good workout with a lot of humidity and uneven stone steps (the steps feel like they were made for giants!)."] },
          { "Day 5: Ubud Exploration & Scenic Attractions": ["The Ubud Art Market is a great place to find beautiful silk scarves, lightweight shirts, statues, kites, handmade woven bags, baskets or hats and many other hand-crafted goods. Locally known as Pasar Seni Ubud, the market is opposite the Puri Saren Royal Ubud Palace and opens daily. Most of the goods found at the Ubud Market are made in the neighbouring villages of Pengosekan, Tegallalang, Payangan and Peliatan. The location of the Ubud Art Market, which is centred among the art producing villages and at the centre of Ubud itself, makes it a strategic shopping place for Balinese handicrafts and souvenirs."] },
          { "Day 6: Relax & Explore Bali at Your Own Pace": ["Day at Leisure Day free at leisure, enjoy by your own."] },
          { "Day 7: Departure – Bali to Denpasar Airport": ["Take a bag full of memories to cherish | Check out from the hotel and meet the representative who will take you to the Denpasar airport to board board your return flight back home."] },
        ],
      hotelsPricing: {
        "4Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Swiss-Belhotel Rainforest Kuta", "The One Legion", "Golden Tulip Jineng Resort", "Kuta Central"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Alam Puisi Ubud", "Ashoka Tree Resort Ubud", "Bhumi Linggah", "Ubud Heaven Sayan"] },
        ],
        "5Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Bintang Bali Resort", "Royal Tulip Springhill Resort", "Pullman Bali Legian Beach"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Asvara Villa Ubud", "FuramaXclusive Resort & Villas", "Hideaway Village Bali"] },
        ],
      },
      optionalActivities: [
        { name: "ATV Quad Bike & White Water Rafting Adventure", costPerAdult: "₹ 5000 /-" },
        { name: "Bali Safari with Marine Park & Jungle Hopper Pass", costPerAdult: "₹ 6000 /-" },
        { name: "Candle Light Dinner", costPerAdult: "₹ 3000 /-" },
        { name: "Lempuyang Temple, Tirta Gangga & Waterfall Tour", costPerAdult: "₹ 2960 /-" },
        { name: "Floating Breakfast", costPerAdult: "₹ 2500 /- per couple" },
      ],
      inclusions: [
        "Arrival in Bali Denpasar and transfer to hotel by private car.",
        "Benoa Water Sports - By Private Car.",
        "Uluwatu Sunset Tour with Kecak Dance on Private car.",
        "Ulundanu Temple of Bedugul tour on Private car.",
        "Git Git Waterfall on Private car.",
        "Tanah Lot Temple on Private car.",
      ],
      exclusions: [
        "International Tourism Levy of IDR 150000 per person.",
        "Visa on Arrival: USD 35 per person.",
      ],
      termsConditions: ["All payment should be cleared at least 30 days before departure."],
      cancellationPolicy: {
        "30DaysOrMore": "25% of total cost",
        "29To20Days": "50% of total cost",
        "19DaysOrLess": "100% of total cost",
      },
    },
    bali4: {
      packageId: "S04390",
      packageName: "Enchanting bali",
      totalGuests: 2,
      nights: 6,
      days: 7,
      startCity: "Mumbai",
      destinationCovered: "Bali",
      totalPackagePrice: "INR 70,000",
 
      packageImage:
        "https://plus.unsplash.com/premium_photo-1661955632358-85564b2810b2?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8YmFsaSUyMGlzbGFuZHxlbnwwfHwwfHx8MA%3D%3D",
        itinerary: [
          { " Day 1: Arrival in Bali & Transfer to Hotel": ["Welcome to Bali! Today is the First day of your trip you will arrive at Denpasar Bali airport and will be transferred to your hotel in Bali. Your first day's schedule depends on the flight arrival time. Usually, this day will be free for you at leisure. Overnight stay at Hotel accommodation"] },
          { "Day 2: Benoa Water Sports": ["Experience a water-filled adventure at Benoa Bay with an exciting. An ideal Bali is incomplete without Bali Water Sport at famous Tanjung Benoa Beach. This beach based know for each aquatic adventure is located in the benoa peninsula far away from the Hustle and bustle. watersport with Banana Boat, Parasailing, Jet Ski."] },
          { " Day 3: Uluwatu Sunset Tour with Kecak Dance": ["Visit the beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. The beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. Post sunset witness the Kecak and Fire Dance - Completely dramatic. Originally from Ramayana this show depicts the famous ‘Lanka Dahan’ episode wherein Hanuman sets fire to the kingdom of Ravana. The enthralling ‘kecak, kecak’ chant is the USP."] },
          { " Day 4: Full-Day West Nusa Penida Tour": ["You will be taken to witness Tegalalang Rice Terraces - probably the busiest and most famous waterfall in Bali, and it’s super easy to reach from Ubud. It only takes about 15 minutes to hike down the steps to the waterfall, but the way back up is a good workout with a lot of humidity and uneven stone steps (the steps feel like they were made for giants!)."] },
          { "Day 5: Ubud Exploration & Scenic Attractions": ["The Ubud Art Market is a great place to find beautiful silk scarves, lightweight shirts, statues, kites, handmade woven bags, baskets or hats and many other hand-crafted goods. Locally known as Pasar Seni Ubud, the market is opposite the Puri Saren Royal Ubud Palace and opens daily. Most of the goods found at the Ubud Market are made in the neighbouring villages of Pengosekan, Tegallalang, Payangan and Peliatan. The location of the Ubud Art Market, which is centred among the art producing villages and at the centre of Ubud itself, makes it a strategic shopping place for Balinese handicrafts and souvenirs."] },
          { "Day 6: Relax & Explore Bali at Your Own Pace": ["Day at Leisure Day free at leisure, enjoy by your own."] },
          { "Day 7: Departure – Bali to Denpasar Airport": ["Take a bag full of memories to cherish | Check out from the hotel and meet the representative who will take you to the Denpasar airport to board board your return flight back home."] },
        ],
      hotelsPricing: {
        "4Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Swiss-Belhotel Rainforest Kuta", "The One Legion", "Golden Tulip Jineng Resort", "Kuta Central"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Alam Puisi Ubud", "Ashoka Tree Resort Ubud", "Bhumi Linggah", "Ubud Heaven Sayan"] },
        ],
        "5Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Bintang Bali Resort", "Royal Tulip Springhill Resort", "Pullman Bali Legian Beach"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Asvara Villa Ubud", "FuramaXclusive Resort & Villas", "Hideaway Village Bali"] },
        ],
      },
      optionalActivities: [
        { name: "ATV Quad Bike & White Water Rafting Adventure", costPerAdult: "₹ 5000 /-" },
        { name: "Bali Safari with Marine Park & Jungle Hopper Pass", costPerAdult: "₹ 6000 /-" },
        { name: "Candle Light Dinner", costPerAdult: "₹ 3000 /-" },
        { name: "Lempuyang Temple, Tirta Gangga & Waterfall Tour", costPerAdult: "₹ 2960 /-" },
        { name: "Floating Breakfast", costPerAdult: "₹ 2500 /- per couple" },
      ],
      inclusions: [
        "Arrival in Bali Denpasar and transfer to hotel by private car.",
        "Benoa Water Sports - By Private Car.",
        "Uluwatu Sunset Tour with Kecak Dance on Private car.",
        "Ulundanu Temple of Bedugul tour on Private car.",
        "Git Git Waterfall on Private car.",
        "Tanah Lot Temple on Private car.",
      ],
      exclusions: [
        "International Tourism Levy of IDR 150000 per person.",
        "Visa on Arrival: USD 35 per person.",
      ],
      termsConditions: ["All payment should be cleared at least 30 days before departure."],
      cancellationPolicy: {
        "30DaysOrMore": "25% of total cost",
        "29To20Days": "50% of total cost",
        "19DaysOrLess": "100% of total cost",
      },
    },

  },
  vietnam: {
    vietnam1: {
      packageId: "S04390",
      packageName: "vietnam highlights",
      totalGuests: 2,
      nights: 6,
      days: 7,
      startCity: "Mumbai",
      destinationCovered: "Bali",
      totalPackagePrice: "INR 70,000",
 
      packageImage:
        "https://plus.unsplash.com/premium_photo-1661955632358-85564b2810b2?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8YmFsaSUyMGlzbGFuZHxlbnwwfHwwfHx8MA%3D%3D",
        itinerary: [
          { " Day 1: Arrival in Bali & Transfer to Hotel": ["Welcome to Bali! Today is the First day of your trip you will arrive at Denpasar Bali airport and will be transferred to your hotel in Bali. Your first day's schedule depends on the flight arrival time. Usually, this day will be free for you at leisure. Overnight stay at Hotel accommodation"] },
          { "Day 2: Benoa Water Sports": ["Experience a water-filled adventure at Benoa Bay with an exciting. An ideal Bali is incomplete without Bali Water Sport at famous Tanjung Benoa Beach. This beach based know for each aquatic adventure is located in the benoa peninsula far away from the Hustle and bustle. watersport with Banana Boat, Parasailing, Jet Ski."] },
          { " Day 3: Uluwatu Sunset Tour with Kecak Dance": ["Visit the beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. The beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. Post sunset witness the Kecak and Fire Dance - Completely dramatic. Originally from Ramayana this show depicts the famous ‘Lanka Dahan’ episode wherein Hanuman sets fire to the kingdom of Ravana. The enthralling ‘kecak, kecak’ chant is the USP."] },
          { " Day 4: Full-Day West Nusa Penida Tour": ["You will be taken to witness Tegalalang Rice Terraces - probably the busiest and most famous waterfall in Bali, and it’s super easy to reach from Ubud. It only takes about 15 minutes to hike down the steps to the waterfall, but the way back up is a good workout with a lot of humidity and uneven stone steps (the steps feel like they were made for giants!)."] },
          { "Day 5: Ubud Exploration & Scenic Attractions": ["The Ubud Art Market is a great place to find beautiful silk scarves, lightweight shirts, statues, kites, handmade woven bags, baskets or hats and many other hand-crafted goods. Locally known as Pasar Seni Ubud, the market is opposite the Puri Saren Royal Ubud Palace and opens daily. Most of the goods found at the Ubud Market are made in the neighbouring villages of Pengosekan, Tegallalang, Payangan and Peliatan. The location of the Ubud Art Market, which is centred among the art producing villages and at the centre of Ubud itself, makes it a strategic shopping place for Balinese handicrafts and souvenirs."] },
          { "Day 6: Relax & Explore Bali at Your Own Pace": ["Day at Leisure Day free at leisure, enjoy by your own."] },
          { "Day 7: Departure – Bali to Denpasar Airport": ["Take a bag full of memories to cherish | Check out from the hotel and meet the representative who will take you to the Denpasar airport to board board your return flight back home."] },
        ],
      hotelsPricing: {
        "4Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Swiss-Belhotel Rainforest Kuta", "The One Legion", "Golden Tulip Jineng Resort", "Kuta Central"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Alam Puisi Ubud", "Ashoka Tree Resort Ubud", "Bhumi Linggah", "Ubud Heaven Sayan"] },
        ],
        "5Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Bintang Bali Resort", "Royal Tulip Springhill Resort", "Pullman Bali Legian Beach"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Asvara Villa Ubud", "FuramaXclusive Resort & Villas", "Hideaway Village Bali"] },
        ],
      },
      optionalActivities: [
        { name: "ATV Quad Bike & White Water Rafting Adventure", costPerAdult: "₹ 5000 /-" },
        { name: "Bali Safari with Marine Park & Jungle Hopper Pass", costPerAdult: "₹ 6000 /-" },
        { name: "Candle Light Dinner", costPerAdult: "₹ 3000 /-" },
        { name: "Lempuyang Temple, Tirta Gangga & Waterfall Tour", costPerAdult: "₹ 2960 /-" },
        { name: "Floating Breakfast", costPerAdult: "₹ 2500 /- per couple" },
      ],
      inclusions: [
        "Arrival in Bali Denpasar and transfer to hotel by private car.",
        "Benoa Water Sports - By Private Car.",
        "Uluwatu Sunset Tour with Kecak Dance on Private car.",
        "Ulundanu Temple of Bedugul tour on Private car.",
        "Git Git Waterfall on Private car.",
        "Tanah Lot Temple on Private car.",
      ],
      exclusions: [
        "International Tourism Levy of IDR 150000 per person.",
        "Visa on Arrival: USD 35 per person.",
      ],
      termsConditions: ["All payment should be cleared at least 30 days before departure."],
      cancellationPolicy: {
        "30DaysOrMore": "25% of total cost",
        "29To20Days": "50% of total cost",
        "19DaysOrLess": "100% of total cost",
      },
    },
    vietnam2: {
      packageId: "S04390",
      packageName: "vietnam package 1",
      totalGuests: 2,
      nights: 6,
      days: 7,
      startCity: "Mumbai",
      destinationCovered: "Bali",
      totalPackagePrice: "INR 70,000",
 
      packageImage:
        "https://plus.unsplash.com/premium_photo-1661955632358-85564b2810b2?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8YmFsaSUyMGlzbGFuZHxlbnwwfHwwfHx8MA%3D%3D",
        itinerary: [
          { " Day 1: Arrival in Bali & Transfer to Hotel": ["Welcome to Bali! Today is the First day of your trip you will arrive at Denpasar Bali airport and will be transferred to your hotel in Bali. Your first day's schedule depends on the flight arrival time. Usually, this day will be free for you at leisure. Overnight stay at Hotel accommodation"] },
          { "Day 2: Benoa Water Sports": ["Experience a water-filled adventure at Benoa Bay with an exciting. An ideal Bali is incomplete without Bali Water Sport at famous Tanjung Benoa Beach. This beach based know for each aquatic adventure is located in the benoa peninsula far away from the Hustle and bustle. watersport with Banana Boat, Parasailing, Jet Ski."] },
          { " Day 3: Uluwatu Sunset Tour with Kecak Dance": ["Visit the beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. The beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. Post sunset witness the Kecak and Fire Dance - Completely dramatic. Originally from Ramayana this show depicts the famous ‘Lanka Dahan’ episode wherein Hanuman sets fire to the kingdom of Ravana. The enthralling ‘kecak, kecak’ chant is the USP."] },
          { " Day 4: Full-Day West Nusa Penida Tour": ["You will be taken to witness Tegalalang Rice Terraces - probably the busiest and most famous waterfall in Bali, and it’s super easy to reach from Ubud. It only takes about 15 minutes to hike down the steps to the waterfall, but the way back up is a good workout with a lot of humidity and uneven stone steps (the steps feel like they were made for giants!)."] },
          { "Day 5: Ubud Exploration & Scenic Attractions": ["The Ubud Art Market is a great place to find beautiful silk scarves, lightweight shirts, statues, kites, handmade woven bags, baskets or hats and many other hand-crafted goods. Locally known as Pasar Seni Ubud, the market is opposite the Puri Saren Royal Ubud Palace and opens daily. Most of the goods found at the Ubud Market are made in the neighbouring villages of Pengosekan, Tegallalang, Payangan and Peliatan. The location of the Ubud Art Market, which is centred among the art producing villages and at the centre of Ubud itself, makes it a strategic shopping place for Balinese handicrafts and souvenirs."] },
          { "Day 6: Relax & Explore Bali at Your Own Pace": ["Day at Leisure Day free at leisure, enjoy by your own."] },
          { "Day 7: Departure – Bali to Denpasar Airport": ["Take a bag full of memories to cherish | Check out from the hotel and meet the representative who will take you to the Denpasar airport to board board your return flight back home."] },
        ],
      hotelsPricing: {
        "4Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Swiss-Belhotel Rainforest Kuta", "The One Legion", "Golden Tulip Jineng Resort", "Kuta Central"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Alam Puisi Ubud", "Ashoka Tree Resort Ubud", "Bhumi Linggah", "Ubud Heaven Sayan"] },
        ],
        "5Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Bintang Bali Resort", "Royal Tulip Springhill Resort", "Pullman Bali Legian Beach"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Asvara Villa Ubud", "FuramaXclusive Resort & Villas", "Hideaway Village Bali"] },
        ],
      },
      optionalActivities: [
        { name: "ATV Quad Bike & White Water Rafting Adventure", costPerAdult: "₹ 5000 /-" },
        { name: "Bali Safari with Marine Park & Jungle Hopper Pass", costPerAdult: "₹ 6000 /-" },
        { name: "Candle Light Dinner", costPerAdult: "₹ 3000 /-" },
        { name: "Lempuyang Temple, Tirta Gangga & Waterfall Tour", costPerAdult: "₹ 2960 /-" },
        { name: "Floating Breakfast", costPerAdult: "₹ 2500 /- per couple" },
      ],
      inclusions: [
        "Arrival in Bali Denpasar and transfer to hotel by private car.",
        "Benoa Water Sports - By Private Car.",
        "Uluwatu Sunset Tour with Kecak Dance on Private car.",
        "Ulundanu Temple of Bedugul tour on Private car.",
        "Git Git Waterfall on Private car.",
        "Tanah Lot Temple on Private car.",
      ],
      exclusions: [
        "International Tourism Levy of IDR 150000 per person.",
        "Visa on Arrival: USD 35 per person.",
      ],
      termsConditions: ["All payment should be cleared at least 30 days before departure."],
      cancellationPolicy: {
        "30DaysOrMore": "25% of total cost",
        "29To20Days": "50% of total cost",
        "19DaysOrLess": "100% of total cost",
      },
    },
    vietnam3: {
      packageId: "S04390",
      packageName: "vietnam package 1",
      totalGuests: 2,
      nights: 6,
      days: 7,
      startCity: "Mumbai",
      destinationCovered: "Bali",
      totalPackagePrice: "INR 70,000",
 
      packageImage:
        "https://plus.unsplash.com/premium_photo-1661955632358-85564b2810b2?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8YmFsaSUyMGlzbGFuZHxlbnwwfHwwfHx8MA%3D%3D",
        itinerary: [
          { " Day 1: Arrival in Bali & Transfer to Hotel": ["Welcome to Bali! Today is the First day of your trip you will arrive at Denpasar Bali airport and will be transferred to your hotel in Bali. Your first day's schedule depends on the flight arrival time. Usually, this day will be free for you at leisure. Overnight stay at Hotel accommodation"] },
          { "Day 2: Benoa Water Sports": ["Experience a water-filled adventure at Benoa Bay with an exciting. An ideal Bali is incomplete without Bali Water Sport at famous Tanjung Benoa Beach. This beach based know for each aquatic adventure is located in the benoa peninsula far away from the Hustle and bustle. watersport with Banana Boat, Parasailing, Jet Ski."] },
          { " Day 3: Uluwatu Sunset Tour with Kecak Dance": ["Visit the beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. The beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. Post sunset witness the Kecak and Fire Dance - Completely dramatic. Originally from Ramayana this show depicts the famous ‘Lanka Dahan’ episode wherein Hanuman sets fire to the kingdom of Ravana. The enthralling ‘kecak, kecak’ chant is the USP."] },
          { " Day 4: Full-Day West Nusa Penida Tour": ["You will be taken to witness Tegalalang Rice Terraces - probably the busiest and most famous waterfall in Bali, and it’s super easy to reach from Ubud. It only takes about 15 minutes to hike down the steps to the waterfall, but the way back up is a good workout with a lot of humidity and uneven stone steps (the steps feel like they were made for giants!)."] },
          { "Day 5: Ubud Exploration & Scenic Attractions": ["The Ubud Art Market is a great place to find beautiful silk scarves, lightweight shirts, statues, kites, handmade woven bags, baskets or hats and many other hand-crafted goods. Locally known as Pasar Seni Ubud, the market is opposite the Puri Saren Royal Ubud Palace and opens daily. Most of the goods found at the Ubud Market are made in the neighbouring villages of Pengosekan, Tegallalang, Payangan and Peliatan. The location of the Ubud Art Market, which is centred among the art producing villages and at the centre of Ubud itself, makes it a strategic shopping place for Balinese handicrafts and souvenirs."] },
          { "Day 6: Relax & Explore Bali at Your Own Pace": ["Day at Leisure Day free at leisure, enjoy by your own."] },
          { "Day 7: Departure – Bali to Denpasar Airport": ["Take a bag full of memories to cherish | Check out from the hotel and meet the representative who will take you to the Denpasar airport to board board your return flight back home."] },
        ],
      hotelsPricing: {
        "4Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Swiss-Belhotel Rainforest Kuta", "The One Legion", "Golden Tulip Jineng Resort", "Kuta Central"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Alam Puisi Ubud", "Ashoka Tree Resort Ubud", "Bhumi Linggah", "Ubud Heaven Sayan"] },
        ],
        "5Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Bintang Bali Resort", "Royal Tulip Springhill Resort", "Pullman Bali Legian Beach"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Asvara Villa Ubud", "FuramaXclusive Resort & Villas", "Hideaway Village Bali"] },
        ],
      },
      optionalActivities: [
        { name: "ATV Quad Bike & White Water Rafting Adventure", costPerAdult: "₹ 5000 /-" },
        { name: "Bali Safari with Marine Park & Jungle Hopper Pass", costPerAdult: "₹ 6000 /-" },
        { name: "Candle Light Dinner", costPerAdult: "₹ 3000 /-" },
        { name: "Lempuyang Temple, Tirta Gangga & Waterfall Tour", costPerAdult: "₹ 2960 /-" },
        { name: "Floating Breakfast", costPerAdult: "₹ 2500 /- per couple" },
      ],
      inclusions: [
        "Arrival in Bali Denpasar and transfer to hotel by private car.",
        "Benoa Water Sports - By Private Car.",
        "Uluwatu Sunset Tour with Kecak Dance on Private car.",
        "Ulundanu Temple of Bedugul tour on Private car.",
        "Git Git Waterfall on Private car.",
        "Tanah Lot Temple on Private car.",
      ],
      exclusions: [
        "International Tourism Levy of IDR 150000 per person.",
        "Visa on Arrival: USD 35 per person.",
      ],
      termsConditions: ["All payment should be cleared at least 30 days before departure."],
      cancellationPolicy: {
        "30DaysOrMore": "25% of total cost",
        "29To20Days": "50% of total cost",
        "19DaysOrLess": "100% of total cost",
      },
    },
    vietnam4: {
      packageId: "S04390",
      packageName: "vietnam package 1",
      totalGuests: 2,
      nights: 6,
      days: 7,
      startCity: "Mumbai",
      destinationCovered: "Bali",
      totalPackagePrice: "INR 70,000",
 
      packageImage:
        "https://plus.unsplash.com/premium_photo-1661955632358-85564b2810b2?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8YmFsaSUyMGlzbGFuZHxlbnwwfHwwfHx8MA%3D%3D",
        itinerary: [
          { " Day 1: Arrival in Bali & Transfer to Hotel": ["Welcome to Bali! Today is the First day of your trip you will arrive at Denpasar Bali airport and will be transferred to your hotel in Bali. Your first day's schedule depends on the flight arrival time. Usually, this day will be free for you at leisure. Overnight stay at Hotel accommodation"] },
          { "Day 2: Benoa Water Sports": ["Experience a water-filled adventure at Benoa Bay with an exciting. An ideal Bali is incomplete without Bali Water Sport at famous Tanjung Benoa Beach. This beach based know for each aquatic adventure is located in the benoa peninsula far away from the Hustle and bustle. watersport with Banana Boat, Parasailing, Jet Ski."] },
          { " Day 3: Uluwatu Sunset Tour with Kecak Dance": ["Visit the beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. The beautiful Uluwatu temple, built on the top of a cliff about 825 feet high facing the vast deep blue Indian Ocean, and catch a wonderful view of sunset. Post sunset witness the Kecak and Fire Dance - Completely dramatic. Originally from Ramayana this show depicts the famous ‘Lanka Dahan’ episode wherein Hanuman sets fire to the kingdom of Ravana. The enthralling ‘kecak, kecak’ chant is the USP."] },
          { " Day 4: Full-Day West Nusa Penida Tour": ["You will be taken to witness Tegalalang Rice Terraces - probably the busiest and most famous waterfall in Bali, and it’s super easy to reach from Ubud. It only takes about 15 minutes to hike down the steps to the waterfall, but the way back up is a good workout with a lot of humidity and uneven stone steps (the steps feel like they were made for giants!)."] },
          { "Day 5: Ubud Exploration & Scenic Attractions": ["The Ubud Art Market is a great place to find beautiful silk scarves, lightweight shirts, statues, kites, handmade woven bags, baskets or hats and many other hand-crafted goods. Locally known as Pasar Seni Ubud, the market is opposite the Puri Saren Royal Ubud Palace and opens daily. Most of the goods found at the Ubud Market are made in the neighbouring villages of Pengosekan, Tegallalang, Payangan and Peliatan. The location of the Ubud Art Market, which is centred among the art producing villages and at the centre of Ubud itself, makes it a strategic shopping place for Balinese handicrafts and souvenirs."] },
          { "Day 6: Relax & Explore Bali at Your Own Pace": ["Day at Leisure Day free at leisure, enjoy by your own."] },
          { "Day 7: Departure – Bali to Denpasar Airport": ["Take a bag full of memories to cherish | Check out from the hotel and meet the representative who will take you to the Denpasar airport to board board your return flight back home."] },
        ],
      hotelsPricing: {
        "4Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Swiss-Belhotel Rainforest Kuta", "The One Legion", "Golden Tulip Jineng Resort", "Kuta Central"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Alam Puisi Ubud", "Ashoka Tree Resort Ubud", "Bhumi Linggah", "Ubud Heaven Sayan"] },
        ],
        "5Star": [
          { city: "Kuta - 4N Deluxe Room", hotels: ["Bintang Bali Resort", "Royal Tulip Springhill Resort", "Pullman Bali Legian Beach"] },
          { city: "Ubud - 2N One Bedroom with Private Pool Villa", hotels: ["Asvara Villa Ubud", "FuramaXclusive Resort & Villas", "Hideaway Village Bali"] },
        ],
      },
      optionalActivities: [
        { name: "ATV Quad Bike & White Water Rafting Adventure", costPerAdult: "₹ 5000 /-" },
        { name: "Bali Safari with Marine Park & Jungle Hopper Pass", costPerAdult: "₹ 6000 /-" },
        { name: "Candle Light Dinner", costPerAdult: "₹ 3000 /-" },
        { name: "Lempuyang Temple, Tirta Gangga & Waterfall Tour", costPerAdult: "₹ 2960 /-" },
        { name: "Floating Breakfast", costPerAdult: "₹ 2500 /- per couple" },
      ],
      inclusions: [
        "Arrival in Bali Denpasar and transfer to hotel by private car.",
        "Benoa Water Sports - By Private Car.",
        "Uluwatu Sunset Tour with Kecak Dance on Private car.",
        "Ulundanu Temple of Bedugul tour on Private car.",
        "Git Git Waterfall on Private car.",
        "Tanah Lot Temple on Private car.",
      ],
      exclusions: [
        "International Tourism Levy of IDR 150000 per person.",
        "Visa on Arrival: USD 35 per person.",
      ],
      termsConditions: ["All payment should be cleared at least 30 days before departure."],
      cancellationPolicy: {
        "30DaysOrMore": "25% of total cost",
        "29To20Days": "50% of total cost",
        "19DaysOrLess": "100% of total cost",
      },
    },

  },
};

export default Finaldata;
